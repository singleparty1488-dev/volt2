# VOLT — работа через GitHub

## Первый push

Распакуйте архив и из корня проекта выполните:

```bash
git init
git add .
git commit -m "feat: prepare VOLT beta 3.1"
git branch -M main
git remote add origin <URL_ВАШЕГО_GITHUB_РЕПОЗИТОРИЯ>
git push -u origin main
```

Если репозиторий уже создан и подключён к Lovable, не переписывайте опубликованную историю через
`force push`, `rebase`, `amend` или `squash`.

## Совместная работа

Для каждой задачи:

```bash
git checkout -b feature/название-задачи
git add .
git commit -m "feat: краткое описание"
git push -u origin feature/название-задачи
```

После этого создайте Pull Request в `main`.

## Локальный запуск

```bash
bun install
bun run dev
```

Проверка перед PR:

```bash
bun run lint
bun run build
```

## Важная настройка beta

Периоды досрочной разблокировки находятся в одном месте:

`src/lib/volt/constants.ts`

- `cooldown` → 60 минут
- `iron` → 24 часа

Они используются одновременно UI, таймером и серверно-нейтральной бизнес-логикой `resolveAttempt`.
