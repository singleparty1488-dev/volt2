import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";

import { InsightCard } from "@/components/volt/InsightCard";
import { PatternMeter, ShareRow } from "@/components/volt/PatternMeter";
import { calculateBehaviorPatterns } from "@/lib/volt/patterns";
import { useVolt } from "@/lib/volt/store";

export const Route = createFileRoute("/patterns")({
  head: () => ({
    meta: [
      { title: "Мои паттерны — VOLT" },
      {
        name: "description",
        content:
          "Как ты принимаешь финансовые решения: спокойный обзор твоих привычек внутри VOLT — паузы, цели и уровни защиты.",
      },
      { property: "og:title", content: "Мои паттерны — VOLT" },
      {
        property: "og:description",
        content: "Личный взгляд на твои финансовые решения — без диагнозов и оценок.",
      },
    ],
  }),
  component: PatternsScreen,
});

function PatternsScreen() {
  const { state } = useVolt();
  const navigate = useNavigate();
  const p = calculateBehaviorPatterns(state);

  return (
    <div className="space-y-5">
      <header className="flex items-center gap-3">
        <button
          type="button"
          aria-label="Назад"
          onClick={() => navigate({ to: "/stats" })}
          className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-secondary/70"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div className="min-w-0">
          <h1 className="truncate text-xl font-bold tracking-tight">Мои паттерны</h1>
          <p className="truncate text-xs text-muted-foreground">
            Как ты принимаешь финансовые решения
          </p>
        </div>
      </header>

      <section className="rounded-[2rem] border border-border/70 bg-card/70 p-5 shadow-[var(--shadow-vault)]">
        <p className="text-xs uppercase tracking-widest text-muted-foreground">Общая картина</p>
        <p className="mt-2 text-base leading-relaxed">{p.overview}</p>
      </section>

      {p.enoughData ? (
        <>
          <section className="grid gap-3">
            {p.scores.map((s) => (
              <PatternMeter
                key={s.id}
                title={s.title}
                score={s.score}
                description={s.description}
                enoughData={s.enoughData}
              />
            ))}
          </section>

          <section className="rounded-3xl border border-border/70 bg-card/60 p-4">
            <p className="text-xs uppercase tracking-widest text-muted-foreground">
              Предпочтения по защите
            </p>
            <div className="mt-3 space-y-3">
              {p.protection.map((l) => (
                <ShareRow key={l.id} label={l.label} dot={l.dot} percent={l.percent} />
              ))}
            </div>
            <p className="mt-3 text-[11px] leading-relaxed text-muted-foreground">
              Ни один уровень не лучше другого — важно только то, что подходит тебе.
            </p>
          </section>

          <section className="rounded-3xl border border-border/70 bg-card/60 p-4">
            <p className="text-xs uppercase tracking-widest text-muted-foreground">
              Самые частые причины
            </p>
            {p.reasons.length ? (
              <div className="mt-3 space-y-3">
                {p.reasons.map((r) => (
                  <ShareRow key={r.reason} label={r.reason} percent={r.percent} />
                ))}
              </div>
            ) : (
              <p className="mt-2 text-sm text-muted-foreground">Пока нет попыток разблокировки.</p>
            )}
          </section>

          <section className="space-y-3">
            <p className="text-xs uppercase tracking-widest text-muted-foreground">Наблюдения</p>
            {p.insights.length ? (
              p.insights.map((i) => <InsightCard key={i.id} text={i.text} tone={i.tone} />)
            ) : (
              <p className="text-sm text-muted-foreground">Пока недостаточно данных.</p>
            )}
          </section>

          <section className="space-y-3">
            <p className="text-xs uppercase tracking-widest text-muted-foreground">
              Что у тебя получается
            </p>
            {p.successes.length ? (
              p.successes.map((i) => <InsightCard key={i.id} text={i.text} tone="positive" />)
            ) : (
              <p className="text-sm text-muted-foreground">Пока недостаточно данных.</p>
            )}
          </section>
        </>
      ) : (
        <p className="rounded-3xl border border-border/60 bg-card/50 p-4 text-sm text-muted-foreground">
          Пока недостаточно данных.
        </p>
      )}

      <p className="text-center text-[11px] leading-relaxed text-muted-foreground">
        Это не психологическая оценка и не диагноз. Все расчёты выполняются на твоём устройстве и
        никуда не отправляются.
      </p>
    </div>
  );
}
