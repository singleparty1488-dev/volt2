import type { ReactNode } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";

import { GoalProgress } from "@/components/volt/GoalProgress";
import { calculateBehaviorPatterns } from "@/lib/volt/patterns";
import { computeStatistics } from "@/lib/volt/stats";
import { formatAmount, pluralDays } from "@/lib/volt/format";
import { useVolt } from "@/lib/volt/store";

export const Route = createFileRoute("/stats")({
  head: () => ({
    meta: [
      { title: "Статистика — VOLT" },
      { name: "description", content: "Сводка по защищённым суммам, завершённым ячейкам и попыткам досрочной разблокировки." },
      { property: "og:title", content: "Статистика — VOLT" },
      { property: "og:description", content: "Ваша финансовая выдержка в цифрах." },
    ],
  }),
  component: StatsScreen,
});

function StatsScreen() {
  const { state } = useVolt();
  const s = computeStatistics(state);
  const p = calculateBehaviorPatterns(state);

  return (
    <div className="space-y-5">
      <header>
        <h1 className="text-2xl font-bold tracking-tight">Статистика</h1>
        <p className="mt-1 text-sm text-muted-foreground">Демо-данные беты</p>
      </header>

      <SectionLabel>Защищённые деньги</SectionLabel>

      <section className="rounded-[2rem] border border-border/70 bg-card/70 p-5 shadow-[var(--shadow-vault)]">
        <p className="text-xs uppercase tracking-widest text-muted-foreground">Под защитой сейчас</p>
        <p className="mt-1 text-3xl font-black">{formatAmount(s.totalProtected)}</p>
        <div className="mt-3 flex items-baseline justify-between border-t border-border/50 pt-3 text-sm">
          <span className="text-muted-foreground">Успешно сохранено</span>
          <span className="font-semibold text-mint">{formatAmount(s.totalPreserved)}</span>
        </div>
      </section>

      <SectionLabel>Ячейки и попытки</SectionLabel>

      <section className="grid grid-cols-2 gap-3">
        <Tile label="Всего ячеек" value={String(s.totalCells)} />
        <Tile label="Завершено" value={String(s.completedCells)} />
        <Tile label="Открыто досрочно" value={String(s.prematurelyUnlockedCells)} />
        <Tile label="Попыток разблокировки" value={String(s.unlockAttempts)} />
        <Tile label="Средний срок защиты" value={pluralDays(s.averageProtectionDays)} />
        <Tile label="Дольше всего без открытия" value={pluralDays(s.longestStreakDays)} />
      </section>

      <section className="rounded-3xl border border-border/70 bg-card/60 p-4">
        <p className="text-xs uppercase tracking-widest text-muted-foreground">Прогресс по целям</p>
        <GoalProgress
          className="mt-3"
          current={s.goalProgress.current}
          target={s.goalProgress.target}
        />
      </section>

      <section className="rounded-3xl border border-border/70 bg-card/60 p-4">
        <p className="text-xs uppercase tracking-widest text-muted-foreground">
          Причины досрочных открытий
        </p>
        <ul className="mt-3 space-y-2">
          {s.unlockReasons.map((r) => (
            <li key={r.reason} className="flex items-baseline justify-between gap-3 text-sm">
              <span className="min-w-0 truncate text-muted-foreground">{r.reason}</span>
              <span className="shrink-0 font-semibold">{r.count}</span>
            </li>
          ))}
        </ul>
      </section>

      <SectionLabel>Мои паттерны</SectionLabel>

      <Link
        to="/patterns"
        className="block rounded-[2rem] border border-border/70 bg-card/70 p-5 shadow-[var(--shadow-vault)] transition-colors hover:border-gold/40"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-sm font-semibold">Как ты принимаешь финансовые решения</p>
            <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
              {p.enoughData ? p.overview : "Пока недостаточно данных."}
            </p>
          </div>
          <ChevronRight className="mt-0.5 h-5 w-5 shrink-0 text-muted-foreground" />
        </div>
        {p.enoughData && (
          <div className="mt-4 grid grid-cols-2 gap-3 border-t border-border/50 pt-3">
            {p.scores.slice(0, 4).map((sc) => (
              <div key={sc.id} className="min-w-0">
                <p className="truncate text-[11px] text-muted-foreground">{sc.title}</p>
                <p className="text-base font-bold tabular-nums">{sc.score}</p>
              </div>
            ))}
          </div>
        )}
      </Link>
    </div>
  );
}

function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <h2 className="pt-1 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
      {children}
    </h2>
  );
}

function Tile({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-3xl border border-border/70 bg-card/60 p-4">
      <p className="text-[11px] uppercase tracking-widest text-muted-foreground">{label}</p>
      <p className="mt-1 text-xl font-bold">{value}</p>
    </div>
  );
}
