import * as React from "react";
import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";

import { CharacterAvatar } from "@/components/volt/CharacterAvatar";
import { CharacterBubble } from "@/components/volt/CharacterBubble";
import { CoolingBanner } from "@/components/volt/CoolingBanner";
import { EventHistory } from "@/components/volt/EventHistory";
import { GoalProgress } from "@/components/volt/GoalProgress";
import { CellOutcomeSequence } from "@/components/volt/CellOutcomeSequence";
import { OutcomeLayer } from "@/components/volt/OutcomeLayer";
import { UnlockFlow } from "@/components/volt/UnlockFlow";
import { VaultReaction } from "@/components/volt/VaultReaction";
import { ProtectionBadge } from "@/components/volt/ProtectionBadge";
import { Button } from "@/components/ui/button";
import {
  BETA_DISCLAIMER,
  CELL_TYPE_MAP,
  COOLING_PERIODS,
  COOLING_WORDING,
  PROTECTION_LEVEL_MAP,
} from "@/lib/volt/constants";
import { daysLeft, formatAmount, formatDate, pluralDays } from "@/lib/volt/format";
import {
  CHARACTER_STATE_META,
  dailySeed,
  getCharacterLine,
  getCharacterState,
} from "@/lib/volt/personality";
import { useVolt } from "@/lib/volt/store";
import { messageSeed } from "@/lib/volt/vaultMessages";

export const Route = createFileRoute("/cell/$cellId")({
  head: () => ({
    meta: [
      { title: "Ячейка — VOLT" },
      { name: "description", content: "Детали защищённой ячейки: сумма, уровень защиты, срок и прогресс цели." },
      { property: "og:title", content: "Ячейка — VOLT" },
      { property: "og:description", content: "Детали защищённой ячейки в VOLT." },
    ],
  }),
  component: CellDetailScreen,
});

function CellDetailScreen() {
  const { cellId } = useParams({ from: "/cell/$cellId" });
  const [unlockOpen, setUnlockOpen] = React.useState(false);
  const { state } = useVolt();
  const navigate = useNavigate();
  const cell = state.cells.find((c) => c.id === cellId);

  if (!cell) {
    return (
      <div className="py-20 text-center text-sm text-muted-foreground">
        Ячейка не найдена.
        <div className="mt-4">
          <Button variant="secondary" onClick={() => navigate({ to: "/" })}>
            В хранилище
          </Button>
        </div>
      </div>
    );
  }

  const left = daysLeft(cell.unlockDate);
  const level = PROTECTION_LEVEL_MAP[cell.protectionLevel];
  const charState = getCharacterState(cell, state.unlockAttempts);
  const line = getCharacterLine(cell.type, charState, dailySeed(cell.id));

  return (
    <div className="space-y-6">
      <header className="flex items-center gap-3">
        <button
          type="button"
          aria-label="Назад"
          onClick={() => navigate({ to: "/" })}
          className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-secondary/70"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>
        <p className="min-w-0 truncate text-sm text-muted-foreground">
          {CELL_TYPE_MAP[cell.type].label}
        </p>
      </header>

      <section className="relative rounded-[2rem] border border-border/70 bg-card/70 p-6 text-center shadow-[var(--shadow-vault)]">
        <OutcomeLayer status={cell.status} />
        <CharacterAvatar type={cell.type} state={charState} size="lg" className="mx-auto" />
        <p className="mt-2 text-[11px] uppercase tracking-widest text-muted-foreground">
          {CHARACTER_STATE_META[charState].label}
        </p>
        <h1 className="mt-1 text-2xl font-bold tracking-tight">{cell.name}</h1>
        <p className="mt-1 text-4xl font-black tracking-tight">
          {formatAmount(cell.amount, cell.currency)}
        </p>
        <div className="mt-3 flex justify-center">
          <ProtectionBadge level={cell.protectionLevel} />
        </div>
        <p className="mt-2 text-xs text-muted-foreground">{level.description}</p>
        <div className="mt-4 flex justify-center">
          <CharacterBubble text={line} className="max-w-xs text-left" />
        </div>
      </section>

      <section className="grid grid-cols-2 gap-3">
        <InfoTile label="Разблокировка" value={formatDate(cell.unlockDate)} />
        <InfoTile
          label="Осталось"
          value={cell.status === "active" ? pluralDays(left) : "Срок истёк"}
        />
      </section>

      {cell.goal && (
        <section className="rounded-3xl border border-border/70 bg-card/60 p-4">
          <p className="text-xs uppercase tracking-widest text-muted-foreground">Цель</p>
          <p className="mt-1 text-base font-semibold">{cell.goal.label}</p>
          {cell.goalAmount ? (
            <GoalProgress
              className="mt-3"
              current={cell.amount}
              target={cell.goalAmount}
              currency={cell.currency}
            />
          ) : null}
        </section>
      )}

      {cell.status === "active" && (
        <section className="rounded-3xl border border-border/70 bg-card/60 p-4">
          <VaultReaction
            context={
              cell.goalAmount && cell.amount / cell.goalAmount >= 0.5
                ? "cell_progress"
                : "cell_created"
            }
            cellType={cell.type}
            seed={messageSeed(cell.id)}
          />
        </section>
      )}

      {cell.status === "completed" && (
        <section className="rounded-3xl border border-border/70 bg-card/60 p-5">
          <CellOutcomeSequence kind="completed" cellType={cell.type} />
        </section>
      )}

      {cell.status === "prematurely_unlocked" && (
        <section className="rounded-3xl border border-border/70 bg-card/60 p-5">
          <CellOutcomeSequence kind="broken" cellType={cell.type} />
        </section>
      )}

      <CoolingBanner cell={cell} />

      <EventHistory cell={cell} attempts={state.unlockAttempts} />

      <section className="space-y-2">
        <Button
          className="w-full rounded-2xl py-6 text-base font-semibold"
          variant="secondary"
          disabled={cell.status !== "active"}
          onClick={() => setUnlockOpen(true)}
        >
          {cell.cooling
            ? COOLING_WORDING[COOLING_PERIODS[cell.protectionLevel]?.kind ?? "cooling"].resume
            : "Разблокировать"}
        </Button>
        <p className="text-center text-[11px] text-muted-foreground">
          Реакция ячейки зависит от выбранного уровня защиты.
        </p>
      </section>

      {unlockOpen && (
        <UnlockFlow cell={cell} onClose={() => setUnlockOpen(false)} />
      )}

      <p className="text-center text-[11px] leading-relaxed text-muted-foreground">
        {BETA_DISCLAIMER}
      </p>
    </div>
  );
}

function InfoTile({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-3xl border border-border/70 bg-card/60 p-4">
      <p className="text-[11px] uppercase tracking-widest text-muted-foreground">{label}</p>
      <p className="mt-1 text-sm font-semibold">{value}</p>
    </div>
  );
}
