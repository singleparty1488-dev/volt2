import { createFileRoute } from "@tanstack/react-router";

import { Lock } from "lucide-react";

import { CellCard } from "@/components/volt/CellCard";
import { CharacterAvatar } from "@/components/volt/CharacterAvatar";
import { CharacterBubble } from "@/components/volt/CharacterBubble";
import { BETA_DISCLAIMER } from "@/lib/volt/constants";
import { daysLeft, formatAmount, pluralDays } from "@/lib/volt/format";
import {
  getCharacterState,
  getVaultGreeting,
  getVaultSenior,
} from "@/lib/volt/personality";
import { useVolt } from "@/lib/volt/store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VOLT — хранилище для ваших денег" },
      {
        name: "description",
        content:
          "VOLT — приложение психологического финансового самоконтроля: защищённые ячейки, цели и осознанные решения о деньгах.",
      },
      { property: "og:title", content: "VOLT — хранилище для ваших денег" },
      {
        property: "og:description",
        content: "Защищённые ячейки помогают не тратить деньги импульсивно.",
      },
    ],
  }),
  component: VaultScreen,
});

function VaultScreen() {
  const { state } = useVolt();
  const active = state.cells.filter((c) => c.status === "active");
  const archive = state.cells.filter((c) => c.status !== "active");
  const totalProtected = active.reduce((s, c) => s + c.amount, 0);
  const senior = getVaultSenior(state.cells);
  const greeting = getVaultGreeting(state.cells, state.unlockAttempts);

  const total = totalProtected + state.freeAmount;
  const ratio = total > 0 ? totalProtected / total : 0;
  const nextDays = active.length ? Math.min(...active.map((c) => daysLeft(c.unlockDate))) : null;
  const initial = (state.user.name.trim()[0] ?? "V").toUpperCase();

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-gold">
          <Lock className="h-4 w-4" strokeWidth={2.2} aria-hidden />
          <h1 className="text-lg font-black tracking-[0.35em] text-foreground">VOLT</h1>
        </div>
        <span
          aria-label={state.user.name}
          className="grid h-9 w-9 place-items-center rounded-full border border-gold/40 bg-vault text-sm font-bold text-gold"
        >
          {initial}
        </span>
      </header>

      <section className="relative overflow-hidden rounded-[2rem] border border-border/70 bg-gradient-to-b from-vault to-vault-deep p-5 shadow-[var(--shadow-vault)]">
        <div
          aria-hidden
          className="pointer-events-none absolute -right-14 -top-14 h-44 w-44 rounded-full bg-gold/10 blur-3xl"
        />
        <div className="relative grid grid-cols-[auto_minmax(0,1fr)] items-center gap-5">
          <VaultRing ratio={ratio} />
          <div className="min-w-0">
            <p className="text-[11px] uppercase tracking-[0.25em] text-muted-foreground">Под защитой</p>
            <p className="mt-1 truncate text-3xl font-black tracking-tight">
              {formatAmount(totalProtected)}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              {total > 0 ? `${Math.round(ratio * 100)}% всех ваших денег в VOLT` : "Пока ничего не защищено"}
            </p>
          </div>
        </div>
        <div className="relative mt-5 grid grid-cols-3 divide-x divide-border/50 border-t border-border/50 pt-4 text-center">
          <Metric label="Свободно" value={formatAmount(state.freeAmount)} />
          <Metric label="Ячеек" value={String(active.length)} />
          <Metric label="Ближайшая" value={nextDays === null ? "—" : pluralDays(nextDays)} />
        </div>
      </section>

      {greeting && senior && (
        <section>
          <div className="flex items-start gap-3">
            <CharacterAvatar
              type={senior.type}
              state={getCharacterState(senior, state.unlockAttempts)}
            />
            <CharacterBubble text={greeting} className="min-w-0 flex-1" />
          </div>
        </section>
      )}

      <section className="space-y-3">
        <h2 className="text-sm font-semibold text-muted-foreground">Активные ячейки</h2>
        {active.length === 0 ? (
          <p className="rounded-3xl border border-dashed border-border/70 p-6 text-center text-sm text-muted-foreground">
            Пока ни одной ячейки. Нажмите «+», чтобы создать первую.
          </p>
        ) : (
          active.map((cell) => <CellCard key={cell.id} cell={cell} />)
        )}
      </section>

      {archive.length > 0 && (
        <section className="space-y-3">
          <h2 className="text-sm font-semibold text-muted-foreground">История</h2>
          {archive.map((cell) => (
            <CellCard key={cell.id} cell={cell} />
          ))}
        </section>
      )}

      <p className="pt-2 text-center text-[11px] leading-relaxed text-muted-foreground">
        {BETA_DISCLAIMER}
      </p>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0 px-2">
      <p className="truncate text-sm font-semibold">{value}</p>
      <p className="mt-0.5 truncate text-[10px] uppercase tracking-widest text-muted-foreground">
        {label}
      </p>
    </div>
  );
}

/** Ring gauge: share of your money that is under protection (real data). */
function VaultRing({ ratio }: { ratio: number }) {
  const r = 34;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative h-24 w-24">
      <svg viewBox="0 0 96 96" className="h-full w-full -rotate-90" aria-hidden>
        <circle cx="48" cy="48" r={r} fill="none" strokeWidth="7" className="stroke-secondary" />
        <circle
          cx="48"
          cy="48"
          r={r}
          fill="none"
          strokeWidth="7"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - ratio)}
          className="stroke-gold transition-[stroke-dashoffset] duration-700 ease-out"
        />
      </svg>
      <Lock
        className="absolute inset-0 m-auto h-7 w-7 text-gold"
        strokeWidth={1.6}
        aria-hidden
      />
    </div>
  );
}
