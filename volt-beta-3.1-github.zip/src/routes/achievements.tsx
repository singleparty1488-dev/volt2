import { createFileRoute } from "@tanstack/react-router";

import { AchievementCard } from "@/components/volt/AchievementCard";
import { ACHIEVEMENTS } from "@/lib/volt/constants";
import { achievementProgress } from "@/lib/volt/stats";
import { useVolt } from "@/lib/volt/store";

export const Route = createFileRoute("/achievements")({
  head: () => ({
    meta: [
      { title: "Достижения — VOLT" },
      { name: "description", content: "Достижения VOLT за стойкость, завершённые ячейки и сохранённые суммы." },
      { property: "og:title", content: "Достижения — VOLT" },
      { property: "og:description", content: "Награды за финансовую выдержку в VOLT." },
    ],
  }),
  component: AchievementsScreen,
});

function AchievementsScreen() {
  const { state } = useVolt();
  const unlocked = ACHIEVEMENTS.filter((a) => achievementProgress(state, a.id) >= a.target).length;

  return (
    <div className="space-y-5">
      <header>
        <h1 className="text-2xl font-bold tracking-tight">Достижения</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Получено {unlocked} из {ACHIEVEMENTS.length}
        </p>
      </header>

      <div className="grid gap-3">
        {ACHIEVEMENTS.map((a) => (
          <AchievementCard key={a.id} achievement={a} progress={achievementProgress(state, a.id)} />
        ))}
      </div>
    </div>
  );
}
