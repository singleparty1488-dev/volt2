import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";

import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { BETA_DISCLAIMER } from "@/lib/volt/constants";
import { isBiometricSupported } from "@/lib/volt/biometrics";
import { useVolt } from "@/lib/volt/store";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Профиль — VOLT" },
      { name: "description", content: "Настройки VOLT: PIN-код, биометрия, автоблокировка, уведомления и приватность." },
      { property: "og:title", content: "Профиль — VOLT" },
      { property: "og:description", content: "Настройки безопасности и приложения VOLT." },
    ],
  }),
  component: ProfileScreen,
});

const AUTO_LOCK_OPTIONS = [1, 5, 15, 60];

function ProfileScreen() {
  const {
    state,
    updateSecurity,
    updateUser,
    lock,
    resetDemo,
    resetAll,
    clearPin,
    enableBiometric,
    disableBiometric,
  } = useVolt();
  const [bioSupported, setBioSupported] = React.useState(false);

  React.useEffect(() => {
    isBiometricSupported().then(setBioSupported);
  }, []);

  return (
    <div className="space-y-5">
      <header className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-4">
        <span className="grid h-14 w-14 shrink-0 place-items-center rounded-3xl bg-secondary/70 text-2xl">
          {state.user.avatarEmoji}
        </span>
        <div className="min-w-0">
          <h1 className="truncate text-xl font-bold">{state.user.name}</h1>
          <p className="truncate text-sm text-muted-foreground">Бета-пользователь VOLT</p>
        </div>
      </header>

      <Section title="Безопасность">
        <Row label="PIN-код" hint={state.security.pinEnabled ? "Включён" : "Выключен"}>
          <Switch
            checked={state.security.pinEnabled}
            onCheckedChange={(v) =>
              v ? updateSecurity({ onboarded: false }) : clearPin()
            }
          />
        </Row>
        <Row
          label="Биометрия"
          hint={bioSupported ? "Face ID / Touch ID устройства" : "Недоступна в этом браузере"}
        >
          <Switch
            disabled={!bioSupported || !state.security.pinEnabled}
            checked={state.security.biometricEnabled}
            onCheckedChange={(v) => (v ? void enableBiometric() : disableBiometric())}
          />
        </Row>
        <div className="px-4 py-3">
          <p className="text-sm">Автоблокировка</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {AUTO_LOCK_OPTIONS.map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => updateSecurity({ autoLockMinutes: m })}
                className={`rounded-full border px-3 py-1.5 text-xs ${
                  state.security.autoLockMinutes === m
                    ? "border-gold/60 bg-gold/10 text-gold"
                    : "border-border/60 bg-card/50 text-muted-foreground"
                }`}
              >
                {m} мин
              </button>
            ))}
          </div>
        </div>
        <div className="px-4 pb-4">
          <Button variant="secondary" className="w-full rounded-2xl" onClick={lock}>
            Заблокировать сейчас
          </Button>
        </div>
      </Section>

      <Section title="Приложение">
        <Row label="Уведомления" hint="Напоминания о сроках">
          <Switch
            checked={state.user.notificationsEnabled}
            onCheckedChange={(v) => updateUser({ notificationsEnabled: v })}
          />
        </Row>
        <Row label="Язык" hint="Русский" />
        <Row label="Оформление" hint="Тёмная тема" />
        <Row label="Приватность" hint="Данные хранятся только на устройстве" />
        <Row label="Резервная копия" hint="Появится в следующем этапе" />
      </Section>

      <Section title="Бета">
        <div className="px-4 py-4 text-xs leading-relaxed text-muted-foreground">
          {BETA_DISCLAIMER}
        </div>
        <div className="px-4 pb-4">
          <Button variant="secondary" className="w-full rounded-2xl" onClick={resetDemo}>
            Загрузить демо-данные
          </Button>
          <Button variant="ghost" className="mt-2 w-full rounded-2xl text-destructive" onClick={resetAll}>
            Стереть все данные
          </Button>
        </div>
      </Section>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section>
      <h2 className="mb-2 px-1 text-xs uppercase tracking-widest text-muted-foreground">{title}</h2>
      <div className="divide-y divide-border/50 overflow-hidden rounded-3xl border border-border/70 bg-card/60">
        {children}
      </div>
    </section>
  );
}

function Row({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 py-3">
      <div className="min-w-0">
        <p className="truncate text-sm">{label}</p>
        {hint && <p className="truncate text-xs text-muted-foreground">{hint}</p>}
      </div>
      {children}
    </div>
  );
}
