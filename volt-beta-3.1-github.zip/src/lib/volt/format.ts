import { CURRENCY } from "./constants";

export function formatAmount(value: number, currency: string = CURRENCY) {
  return `${new Intl.NumberFormat("ru-RU").format(Math.round(value))} ${currency}`;
}

export function daysLeft(isoDate: string, from: Date = new Date()) {
  const target = new Date(isoDate).getTime();
  const start = new Date(from.getFullYear(), from.getMonth(), from.getDate()).getTime();
  return Math.max(0, Math.ceil((target - start) / 86_400_000));
}

export function formatDate(isoDate: string) {
  return new Intl.DateTimeFormat("ru-RU", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(isoDate));
}

export function pluralDays(n: number) {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return `${n} день`;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return `${n} дня`;
  return `${n} дней`;
}

export function addDays(days: number, from: Date = new Date()) {
  const d = new Date(from);
  d.setDate(d.getDate() + days);
  return d.toISOString();
}

/** 3725 → "01:02:05". Used for the cooling / freeze countdown (up to 24h and beyond). */
export function formatCountdown(totalSeconds: number) {
  const s = Math.max(0, Math.floor(totalSeconds));
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(Math.floor(s / 3600))}:${pad(Math.floor((s % 3600) / 60))}:${pad(s % 60)}`;
}

/** "21 сент., 19:35" — moment when a waiting period ends. */
export function formatDateTime(isoDate: string) {
  return new Intl.DateTimeFormat("ru-RU", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(isoDate));
}
