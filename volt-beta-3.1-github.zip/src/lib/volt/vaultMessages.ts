// ============= VOLT microcopy (Phase 5) =============
//
// Single source of every emotional line in the app. Nothing emotional should
// be typed inline in a component — add it here instead.
//
// Tone: witty, warm, slightly sarcastic, supportive. Never guilt, never
// insults, never manipulation.

import type { CellTypeId, ProtectionLevelId } from "./types";

export type MoodId =
  | "happy"
  | "calm"
  | "excited"
  | "worried"
  | "scared"
  | "sad"
  | "celebrating";

export const MOOD_META: Record<MoodId, { face: string; label: string }> = {
  happy: { face: "🙂", label: "Доволен" },
  calm: { face: "😌", label: "Спокоен" },
  excited: { face: "😎", label: "Воодушевлён" },
  worried: { face: "😟", label: "Волнуется" },
  scared: { face: "😰", label: "Напуган" },
  sad: { face: "😢", label: "Грустит" },
  celebrating: { face: "🎉", label: "Празднует" },
};

export type ReactionContext =
  | "cell_created"
  | "cell_progress"
  | "unlock_attempt"
  | "cooling"
  | "unlock_cancelled"
  | "unlock_confirmed"
  | "cell_completed";

/** Default mood per context — can be overridden by protection level. */
export const CONTEXT_MOOD: Record<ReactionContext, MoodId> = {
  cell_created: "happy",
  cell_progress: "excited",
  unlock_attempt: "worried",
  cooling: "scared",
  unlock_cancelled: "calm",
  unlock_confirmed: "sad",
  cell_completed: "celebrating",
};

const BASE_MESSAGES: Record<ReactionContext, string[]> = {
  cell_created: [
    "Ну что, начинаем.",
    "Первый шаг сделан.",
    "Эти деньги теперь под присмотром.",
  ],
  cell_progress: ["Мы растём.", "Неплохо идём.", "Ещё немного.", "Смотри, как мы выросли."],
  unlock_attempt: ["Эй… подожди.", "Ты точно хочешь это сделать?", "Давай сначала подумаем."],
  cooling: [
    "Решение никуда не убежит.",
    "Час ничего не изменит. Зато многое прояснит.",
    "Оставим это решение на потом?",
  ],
  unlock_cancelled: ["Хорошо.", "Фух.", "Это было осознанно."],
  unlock_confirmed: [
    "Ну… мы старались.",
    "Похоже, сегодня победила эта покупка.",
    "Ладно. Решение твоё.",
  ],
  cell_completed: ["Мы сделали это.", "Ты сдержал своё решение.", "Ячейка дошла до конца."],
};

/** Emotional intensity of the unlock attempt scales with protection level. */
const PROTECTION_ATTEMPT: Record<ProtectionLevelId, { mood: MoodId; lines: string[] }> = {
  calm: { mood: "happy", lines: ["Ты уверен?", "Ок, просто уточняю: точно сейчас?"] },
  mindful: {
    mood: "worried",
    lines: [
      "Давай сначала разберёмся, зачем нам эти деньги.",
      "Пара вопросов — и я не мешаю.",
    ],
  },
  cooldown: {
    mood: "scared",
    lines: ["Мы можем решить это через час.", "Дай импульсу немного остыть."],
  },
  iron: {
    mood: "sad",
    lines: [
      "Ты сам попросил меня охранять эти деньги…",
      "Я держался как мог. Но выбор всё равно твой.",
    ],
  },
};

/** Cooling-screen lines per level: «охлаждение» (60 min) and «заморозка» (24 h). */
const PROTECTION_COOLING: Partial<Record<ProtectionLevelId, string[]>> = {
  cooldown: [
    "Час ничего не изменит. Зато многое прояснит.",
    "Через час вернёмся к этому вопросу вместе.",
    "Импульсы не любят ждать. Подождём?",
  ],
  iron: [
    "Утро вечера мудренее. Сутки — и всё станет яснее.",
    "Заморозка — это пауза, о которой ты сам попросил.",
    "Ты выбрал этот срок заранее. Я просто держу слово вместе с тобой.",
  ],
};

/** Light per-cell-type flavour. Kept deliberately subtle. */
const TYPE_MESSAGES: Partial<
  Record<CellTypeId, Partial<Record<ReactionContext, string[]>>>
> = {
  glass_house: {
    cell_created: ["Свет включён. Уютно устроились."],
    cell_progress: ["В домике всё на виду — и всё идёт по плану."],
    unlock_confirmed: ["Свет придётся выключить. Бывает."],
  },
  piggy_bank: {
    cell_created: ["Хрю! Монетки, заходите."],
    cell_progress: ["Внутри уже звенит приятно."],
    unlock_attempt: ["Только не по керамике, пожалуйста."],
  },
  jar: {
    cell_created: ["Крышка закручена. Просто и надёжно."],
    cell_progress: ["Уровень поднимается."],
  },
  money_plant: {
    cell_created: ["Посадили. Осталось не мешать расти."],
    cell_progress: ["Новый листик. Это хороший знак."],
    cell_completed: ["Мы доросли до плодов."],
  },
  safe: {
    cell_created: ["Дверца закрыта. Я на посту."],
    cell_progress: ["Толстые стены, спокойный сон."],
    unlock_attempt: ["Комбинация принята. Но я обязан спросить."],
  },
};

export interface VaultMessage {
  mood: MoodId;
  text: string;
}

/**
 * Pick a message for a context. Pass a `seed` for deterministic output
 * (e.g. cell id + day); omit it for a random variant on transient events.
 */
export function getVaultMessage(
  context: ReactionContext,
  options: {
    cellType?: CellTypeId | undefined;
    protectionLevel?: ProtectionLevelId | undefined;
    seed?: number | undefined;
  } = {},
): VaultMessage {
  const { cellType, protectionLevel, seed } = options;

  let mood = CONTEXT_MOOD[context];
  let pool = BASE_MESSAGES[context];

  if (context === "unlock_attempt" && protectionLevel) {
    const byLevel = PROTECTION_ATTEMPT[protectionLevel];
    mood = byLevel.mood;
    pool = byLevel.lines;
  } else if (context === "cooling" && protectionLevel && PROTECTION_COOLING[protectionLevel]) {
    pool = PROTECTION_COOLING[protectionLevel] ?? pool;
  } else if (cellType && TYPE_MESSAGES[cellType]?.[context]?.length) {
    pool = [...(TYPE_MESSAGES[cellType]?.[context] ?? []), ...BASE_MESSAGES[context]];
  }

  const index =
    seed === undefined
      ? Math.floor(Math.random() * pool.length)
      : Math.abs(seed) % pool.length;

  return { mood, text: pool[index] ?? BASE_MESSAGES[context][0]! };
}

/** Stable seed helper for non-random, day-stable messages. */
export function messageSeed(key: string, now: number = Date.now()): number {
  let h = Math.floor(now / 86_400_000);
  for (let i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) | 0;
  return h;
}
