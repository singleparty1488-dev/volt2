/**
 * Biometrics via WebAuthn platform authenticator (Face ID / Touch ID / Android).
 * VOLT never sees biometric data. Beta is local-only (no server): the credential is
 * created and asserted on-device with userVerification "required", so the OS shows
 * its real biometric prompt; the signature is not verified server-side (no backend yet).
 */
export async function isBiometricSupported(): Promise<boolean> {
  if (typeof window === "undefined" || !window.PublicKeyCredential) return false;
  try {
    return await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
  } catch {
    return false;
  }
}

const toB64 = (buf: ArrayBuffer) =>
  btoa(String.fromCharCode(...new Uint8Array(buf)))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");

const fromB64 = (s: string) => {
  const pad = "=".repeat((4 - (s.length % 4)) % 4);
  const bin = atob(s.replace(/-/g, "+").replace(/_/g, "/") + pad);
  return Uint8Array.from(bin, (c) => c.charCodeAt(0));
};

/** Creates a platform credential (real OS prompt). Returns its id, or null if refused/unsupported. */
export async function registerBiometric(userId: string, userName: string): Promise<string | null> {
  if (!(await isBiometricSupported())) return null;
  try {
    const cred = (await navigator.credentials.create({
      publicKey: {
        challenge: crypto.getRandomValues(new Uint8Array(32)),
        rp: { name: "VOLT" },
        user: { id: new TextEncoder().encode(userId), name: userName, displayName: userName },
        pubKeyCredParams: [
          { type: "public-key", alg: -7 },
          { type: "public-key", alg: -257 },
        ],
        authenticatorSelection: {
          authenticatorAttachment: "platform",
          userVerification: "required",
          residentKey: "discouraged",
        },
        attestation: "none",
        timeout: 60_000,
      },
    })) as PublicKeyCredential | null;
    return cred ? toB64(cred.rawId) : null;
  } catch {
    return null;
  }
}

/** Asks the OS to verify the user with the registered credential. */
export async function verifyBiometric(credentialId: string | null): Promise<boolean> {
  if (!credentialId) return false;
  try {
    const assertion = await navigator.credentials.get({
      publicKey: {
        challenge: crypto.getRandomValues(new Uint8Array(32)),
        allowCredentials: [{ type: "public-key", id: fromB64(credentialId) }],
        userVerification: "required",
        timeout: 60_000,
      },
    });
    return !!assertion;
  } catch {
    return false;
  }
}
